function logout(element){
    element.innerText = "logout"
}
function disappear (element){
    element.remove ();
}
